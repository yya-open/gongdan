import { onRequestPost as __api_tickets_trash_bulk_hard_js_onRequestPost } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\trash\\bulk-hard.js"
import { onRequestDelete as __api_tickets_trash_empty_js_onRequestDelete } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\trash\\empty.js"
import { onRequestDelete as __api_tickets__id__hard_js_onRequestDelete } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\[id]\\hard.js"
import { onRequestPut as __api_tickets__id__restore_js_onRequestPut } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\[id]\\restore.js"
import { onRequestPost as __api_import_apply_js_onRequestPost } from "D:\\12.25\\gongdan\\functions\\api\\import\\apply.js"
import { onRequestPost as __api_import_preview_js_onRequestPost } from "D:\\12.25\\gongdan\\functions\\api\\import\\preview.js"
import { onRequestDelete as __api_tickets_purge_all_js_onRequestDelete } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\purge-all.js"
import { onRequestDelete as __api_tickets__id__js_onRequestDelete } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\[id].js"
import { onRequestPut as __api_tickets__id__js_onRequestPut } from "D:\\12.25\\gongdan\\functions\\api\\tickets\\[id].js"
import { onRequestGet as __api_auth_test_js_onRequestGet } from "D:\\12.25\\gongdan\\functions\\api\\auth-test.js"
import { onRequestGet as __api_danger_test_js_onRequestGet } from "D:\\12.25\\gongdan\\functions\\api\\danger-test.js"
import { onRequestPut as __api_import_js_onRequestPut } from "D:\\12.25\\gongdan\\functions\\api\\import.js"
import { onRequestGet as __api_tickets_js_onRequestGet } from "D:\\12.25\\gongdan\\functions\\api\\tickets.js"
import { onRequestPost as __api_tickets_js_onRequestPost } from "D:\\12.25\\gongdan\\functions\\api\\tickets.js"

export const routes = [
    {
      routePath: "/api/tickets/trash/bulk-hard",
      mountPath: "/api/tickets/trash",
      method: "POST",
      middlewares: [],
      modules: [__api_tickets_trash_bulk_hard_js_onRequestPost],
    },
  {
      routePath: "/api/tickets/trash/empty",
      mountPath: "/api/tickets/trash",
      method: "DELETE",
      middlewares: [],
      modules: [__api_tickets_trash_empty_js_onRequestDelete],
    },
  {
      routePath: "/api/tickets/:id/hard",
      mountPath: "/api/tickets/:id",
      method: "DELETE",
      middlewares: [],
      modules: [__api_tickets__id__hard_js_onRequestDelete],
    },
  {
      routePath: "/api/tickets/:id/restore",
      mountPath: "/api/tickets/:id",
      method: "PUT",
      middlewares: [],
      modules: [__api_tickets__id__restore_js_onRequestPut],
    },
  {
      routePath: "/api/import/apply",
      mountPath: "/api/import",
      method: "POST",
      middlewares: [],
      modules: [__api_import_apply_js_onRequestPost],
    },
  {
      routePath: "/api/import/preview",
      mountPath: "/api/import",
      method: "POST",
      middlewares: [],
      modules: [__api_import_preview_js_onRequestPost],
    },
  {
      routePath: "/api/tickets/purge-all",
      mountPath: "/api/tickets",
      method: "DELETE",
      middlewares: [],
      modules: [__api_tickets_purge_all_js_onRequestDelete],
    },
  {
      routePath: "/api/tickets/:id",
      mountPath: "/api/tickets",
      method: "DELETE",
      middlewares: [],
      modules: [__api_tickets__id__js_onRequestDelete],
    },
  {
      routePath: "/api/tickets/:id",
      mountPath: "/api/tickets",
      method: "PUT",
      middlewares: [],
      modules: [__api_tickets__id__js_onRequestPut],
    },
  {
      routePath: "/api/auth-test",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_auth_test_js_onRequestGet],
    },
  {
      routePath: "/api/danger-test",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_danger_test_js_onRequestGet],
    },
  {
      routePath: "/api/import",
      mountPath: "/api",
      method: "PUT",
      middlewares: [],
      modules: [__api_import_js_onRequestPut],
    },
  {
      routePath: "/api/tickets",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_tickets_js_onRequestGet],
    },
  {
      routePath: "/api/tickets",
      mountPath: "/api",
      method: "POST",
      middlewares: [],
      modules: [__api_tickets_js_onRequestPost],
    },
  ]